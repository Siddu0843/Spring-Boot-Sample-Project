package com.demo.bankapp.response;

import lombok.Data;

@Data
public class CreateUserResponse {
	private String username;
	private String tcno;
}
