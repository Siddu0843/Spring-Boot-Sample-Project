package com.demo.bankapp.request;

public class BaseRequest {

}
